var parent = require('../../stable/typed-array/includes');

module.exports = parent;
