var parent = require('../../stable/typed-array/find');

module.exports = parent;
