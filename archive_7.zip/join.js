var parent = require('../../stable/typed-array/join');

module.exports = parent;
