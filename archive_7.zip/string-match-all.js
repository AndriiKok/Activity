// https://github.com/tc39/proposal-string-matchall
require('../modules/esnext.string.match-all');
