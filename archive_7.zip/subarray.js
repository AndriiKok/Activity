var parent = require('../../stable/typed-array/subarray');

module.exports = parent;
