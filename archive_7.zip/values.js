var parent = require('../../stable/typed-array/values');

module.exports = parent;
