var parent = require('../../stable/typed-array/find-index');

module.exports = parent;
