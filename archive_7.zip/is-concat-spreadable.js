var parent = require('../../stable/symbol/is-concat-spreadable');

module.exports = parent;
