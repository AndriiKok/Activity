// https://github.com/tc39/proposal-promise-allSettled
require('../modules/esnext.promise.all-settled');
