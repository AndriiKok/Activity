// https://github.com/caitp/TC39-Proposals/blob/trunk/tc39-reflect-isconstructor-iscallable.md
require('../modules/esnext.function.is-callable');
require('../modules/esnext.function.is-constructor');
