// https://github.com/tc39/proposal-string-left-right-trim
require('../modules/es.string.trim-start');
require('../modules/es.string.trim-end');
