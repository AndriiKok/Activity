// https://github.com/tc39/proposal-pattern-matching
require('../modules/esnext.symbol.matcher');
// TODO: remove from `core-js@4`
require('../modules/esnext.symbol.pattern-match');
