require('../../modules/esnext.typed-array.to-spliced');
