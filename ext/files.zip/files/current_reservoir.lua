return process_tick(now, false)['reservoir']
