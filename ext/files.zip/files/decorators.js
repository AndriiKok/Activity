// TODO: The metadata API is splitting out into a separate Stage 2 proposal
// so required a new entry point for it when it will be finally formed
// https://github.com/tc39/proposal-decorators
require('../modules/esnext.symbol.metadata');
