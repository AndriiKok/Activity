"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var DisclosureTriangleRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'summary'
    }
  }],
  type: 'widget'
};
var _default = DisclosureTriangleRole;
exports["default"] = _default;