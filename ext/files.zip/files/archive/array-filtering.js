// https://github.com/tc39/proposal-array-filtering
// TODO: Remove from `core-js@4`
require('../modules/esnext.array.filter-out');
require('../modules/esnext.array.filter-reject');
// TODO: Remove from `core-js@4`
require('../modules/esnext.typed-array.filter-out');
require('../modules/esnext.typed-array.filter-reject');
