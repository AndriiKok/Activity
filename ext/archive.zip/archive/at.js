var parent = require('../../stable/typed-array/every');

module.exports = parent;
