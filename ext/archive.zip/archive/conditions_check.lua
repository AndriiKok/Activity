local conditions_check = function (capacity, weight)
  return capacity == nil or weight <= capacity
end
