"use strict";

var BottleneckError;
BottleneckError = class BottleneckError extends Error {};
module.exports = BottleneckError;