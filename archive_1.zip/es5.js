"use strict";

require("regenerator-runtime/runtime");

module.exports = require("./Bottleneck");