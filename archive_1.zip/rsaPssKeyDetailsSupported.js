const semver = require('semver');

module.exports = semver.satisfies(process.version, '>=16.9.0');
