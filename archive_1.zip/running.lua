return process_tick(now, false)['running']
