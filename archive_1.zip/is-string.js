export default function isString(input) {
    return typeof input === 'string' || input instanceof String;
}
