const VERSION = "14.1.0";
export {
  VERSION
};
