"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var DefinitionRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'dfn'
    }
  }],
  type: 'structure'
};
var _default = DefinitionRole;
exports["default"] = _default;