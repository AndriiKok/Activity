"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var SVGRootRole = {
  relatedConcepts: [],
  type: 'structure'
};
var _default = SVGRootRole;
exports["default"] = _default;