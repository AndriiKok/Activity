"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var LineBreakRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'br'
    }
  }],
  type: 'structure'
};
var _default = LineBreakRole;
exports["default"] = _default;