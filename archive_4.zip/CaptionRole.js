"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var CaptionRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'caption'
    }
  }],
  type: 'structure'
};
var _default = CaptionRole;
exports["default"] = _default;