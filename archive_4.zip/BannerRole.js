"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var BannerRole = {
  relatedConcepts: [{
    module: 'ARIA',
    concept: {
      name: 'banner'
    }
  }],
  type: 'structure'
};
var _default = BannerRole;
exports["default"] = _default;