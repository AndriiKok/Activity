"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var InlineTextBoxRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'input'
    }
  }],
  type: 'widget'
};
var _default = InlineTextBoxRole;
exports["default"] = _default;