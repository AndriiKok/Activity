"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var AlertRole = {
  relatedConcepts: [{
    module: 'ARIA',
    concept: {
      name: 'alert'
    }
  }],
  type: 'structure'
};
var _default = AlertRole;
exports["default"] = _default;