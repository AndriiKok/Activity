"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var EmbeddedObjectRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'embed'
    }
  }],
  type: 'widget'
};
var _default = EmbeddedObjectRole;
exports["default"] = _default;