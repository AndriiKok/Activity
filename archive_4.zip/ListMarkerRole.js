"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var ListMarkerRole = {
  relatedConcepts: [],
  type: 'structure'
};
var _default = ListMarkerRole;
exports["default"] = _default;