"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var FooterRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'footer'
    }
  }],
  type: 'structure'
};
var _default = FooterRole;
exports["default"] = _default;