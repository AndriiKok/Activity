"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var ImageMapLinkRole = {
  relatedConcepts: [],
  type: 'widget'
};
var _default = ImageMapLinkRole;
exports["default"] = _default;