"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var LabelRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'label'
    }
  }],
  type: 'structure'
};
var _default = LabelRole;
exports["default"] = _default;