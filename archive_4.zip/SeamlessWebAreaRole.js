"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var SeamlessWebAreaRole = {
  relatedConcepts: [],
  type: 'structure'
};
var _default = SeamlessWebAreaRole;
exports["default"] = _default;